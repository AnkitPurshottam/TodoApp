rds_hostname = "ankit.cmxhtaqpkza4.ap-south-1.rds.amazonaws.com"
rds_username = "ankitp"
rds_password = "0ZYqUOTeYzeh1Su0j0It"
rds_database = "mytodo"